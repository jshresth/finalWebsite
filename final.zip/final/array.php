<?php
$deals=array();
$deals[1] = array("id"=> "#kitchen", "img"=>"kitchen.png","alt"=>"kitchen appliances");
$deals[2] = array("id"=> "#fitness", "img"=>"fitness.jpg","alt"=>"fitness appliances");
$deals[3] = array("id"=> "#beauty", "img"=>"face.png","alt"=>"beauty products");
$deals[4] = array("id"=> "#hair", "img"=>"newhair.png","alt"=>"hair products");
?>