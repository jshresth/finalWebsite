<?php
session_start();
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8">
   <link rel="shortcut icon" href="images/loho.jpg" />
   <title>TeleShop Nepal</title>
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
   <link rel="stylesheet" href="css/style.css" type="text/css">
   <link rel="stylesheet" href="css/index.css">
     <!-- <link rel="stylesheet" href="css/catalog.css"> -->
   <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

</head>
<body>
	<div>
		<?php
            include 'header.php';
           ?>
	
	<div class="container">
<div class="row">
	<div class="col-md-6">

<div class="Headings">
<h3>HIGH PRESSURE WASHER</h3>
</div>
<div class="clear"></div>
<div>
<video id="video1" poster="" controls width="480"
height="360">
<source src="images/High Pressure Washer.mp4" type="video/mp4">
not supported
</video>
</div>
</div>


<div class="col-md-6">
<div class="Headings">
<h3>Hot Shapers</h3>
</div>
<div class="clear"></div>

<div>
<iframe allowfullscreen="" frameborder="0" height="360" src="https://www.youtube.com/embed/fVt1-QkpZkI" width="480"></iframe>
</div>
</div>

<div class="col-md-6">
<div class="Headings">
<h3>Six Pack Care</h3>
</div>
<div class="clear"></div>

<div>

<p><iframe allowfullscreen="" frameborder="0" height="360" src="https://www.youtube.com/embed/Pe9b6emRAi8" width="480"></iframe></p>
</div>
</div>

<div class="col-md-6">
<div class="Headings">
<h3>Salad Chef</h3>
</div>
<div class="clear"></div>
<div>

<p><iframe allowfullscreen="" frameborder="0" height="360" src="https://www.youtube.com/embed/a_r6fdCOt-I" width="480"></iframe></p></div>
</div>

<div class="col-md-6">
<div class="Headings">
<h3>Herbal Tea</h3>
</div>
<div class="clear"></div>

<div>

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fteleshopnepalofficial%2Fvideos%2F350661625880511%2F&show_text=0&width=560" width="480" height="360" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
</div>
</div>

<div class="col-md-6">
<div class="Headings">
<h3>Electric Full Body Massaging Mat</h3>
</div>
<div class="clear"></div>

<div>
<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fteleshopnepalofficial%2Fvideos%2F2394878644087932%2F&show_text=0&width=560" width="480" height="360" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
</div>
</div>
<!--<p><video src="https://www.youtube.com/watch?time_continue=1&v=fUNYj6ziCww" height="360"  width="480"></p></div>-->



<div class="col-md-6">
<div class="Headings">
<h3>Hair Brush plus Straightner</h3>
</div>
<div class="clear"></div>

<div>

	<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fteleshopnepalofficial%2Fvideos%2F2466898793367871%2F&show_text=0&width=560" width="480" height="360" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
</div>
</div>
</div>
</div>
  
   <br><br> <br><br>
           <?php
           	include 'footer.php';
           ?>



</div>
</body>
</html>