<div class="footer">
   <div class="row">
      <div class="col-md-4" style="font-size: 14px">
         <p> <a href="about.php">Contact Us </a></p>
         <p>Old Baneshwor</p>
         <p> Kathmandu, Nepal </p>
         <p> +977 9845076376</p>
         <p> support@teleshop.com</p>
      </div>

      <div class="col-md-4 social-icons">
         <div class="row">
            <div class="col-md-6">
         <h4> Follow Us</h4>
         <ul style="display:flex;">
         <a href="#" target="_blank"><img src="images/icons/facebook.png" alt="" /></a>
         <a href="#" target="_blank"><img src="images/icons/twitter.png" alt="" /></a>
         <a href="#" target="_blank"><img src="images/icons/insta.png" alt=""/>
         </a>
      </ul>
   </div>
   <div class="cold-md-6">
      <a href="location.php" class="btn btn-default" style="background-color: #820813; color: white; border-color: grey">Find Us</a>
   </div>
   </div>
</div>
   <div class="col-md-4">
      <h5>About the Company</h5>
         <p> Tele-shop Nepal is the ultimate shopping solution for all our special customers from nepal. It offers a wide and assorted range of products.</p>
      </div>
   </div>

   <div class="clear"> </div>
   <div class="copy_right">
   <p>&copy;2019 Tele_Shop Nepal. All rights reserved</p>
</div>
</div>




